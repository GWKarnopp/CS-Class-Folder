#include <iostream>
using namespace std;

int main()
{
	float price;
	cout << "What is the Price of you item?" << endl;
	cin >> price;

	string city;
	cout << "What city are you in?" << endl;
	cin >> city;







	int tax, storeprice = (price + (price * tax));

	if (city = Olathe)
	{
		cout << "Total Price is: " << 
	}
	else if ( city = OverlandPark )
	{
		cout << "Total Price is: " <<
	}
	else if ( city = Raytown )
	{
		cout << "Total Price is: " <<
	}
	else if ( city = Independence )
	{
		cout << "Total Price is: " <<
	}
	else
	{
		cout << "Total Price is: " <<
	}








	return 0;
}
