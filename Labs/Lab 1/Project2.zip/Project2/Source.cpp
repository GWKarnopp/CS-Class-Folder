#include <iostream>
#include <string>
using namespace std;

int main()
{
	// Variable declarations
	string name, color;

	// Output and input
	cout << "Hello, what is your name? ";
	cin >> name;

	cout << "What is your favorite color? ";
	cin >> color;

	#include <iostream>
#include <string>
using namespace std;

int main()
{
    // Variable declarations
    string name, color;

    // Output and input
    cout << "Hello, what is your name? ";
    cin >> name;

    cout << "What is your favorite color? ";
    cin >> color;

    cout << endl;
    cout << "Do people call you " << color << " " << name << "?" << endl;

	cout << endl;
	cout << "So can I call you " << color << " " << name << "?" << endl;

	// test 1 2 3

    return 0;
}




	// test 1 2 3

	return 0;
}
