#include <iostream>
using namespace std;

int main()
{
	int secretNumber = 17, playerGuess;
	do
	{
		cout << "Enter your guess: ";
		cin >> playerGuess;

		if (playerGuess < secretNumber)
		{
			cout << "too low!" << endl;
		}
		else if (playerGuess > secretNumber)
		{
			cout << "Too high!" << endl; 
		}
	}
	while (playerGuess != secretNumber)
	{
		cout << "You WIN!!!" << endl;
	}

	return 0
}