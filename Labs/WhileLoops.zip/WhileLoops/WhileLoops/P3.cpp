#include <iostream>
using namespace std;

int main()
{
	int counter = 0;
	while (counter <= 20)
	{
		cout << counter << " ";
		counter += 5;
	}

	cout << endl << endl << "Done!" << endl;

	return 0
}