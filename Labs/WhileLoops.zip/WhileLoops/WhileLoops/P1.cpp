#include <iostream>
using namespace std;

int main()
{
	int coutUp = 1:
	while (coutUp < 11)
	{
		cout << countUp << " ";
		countUp++;
	}

	cout << endl << endl < , "Done!" << endl;

	return 0;
}