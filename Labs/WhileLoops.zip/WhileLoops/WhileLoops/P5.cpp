#include <iostream>
using namespace std;

int main()
{
	cout << "Please enter a number between 0 and 5" << endl;
	int choice;
	cin >> choice;
	while (choice < 0 || choice > 5)
	{
		cout << "invalid entry, try again: ";
		cin >> choice;
	}

	cout << "Thank You!" << endl;

	return 0;
}