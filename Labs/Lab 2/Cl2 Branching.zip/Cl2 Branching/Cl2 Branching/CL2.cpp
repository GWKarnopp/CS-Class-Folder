#include <iostream>
#include <string>
using namespace std;

int main()
{	
	float ratio;
	cout << "How many batches do you want to make?" << endl;
	cin >> ratio;

	float tspbakingsoda = 1 * ratio;
	float tspbakingpowder = 0.5 * ratio;
	float cupsofbutter = 1 * ratio;
	float cupsofsugar = 1.5 * ratio;
	float eggs = 1 * ratio;

	cout << tspbakingsoda << "tsp baking soda" << endl;
	cout << tspbakingpowder << "tsp baking powder" << endl;
	cout << cupsofbutter << "cups of butter" << endl;
	cout << cupsofsugar << "cups white sugar" << endl;
	cout << eggs << "1 egg" << endl;

	while (true); // kludgey fix
	return 0;
}