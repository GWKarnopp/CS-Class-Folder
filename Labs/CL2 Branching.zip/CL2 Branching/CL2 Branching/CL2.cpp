#include <iostream>
#include <string>
using namespace std;

int main()
{
	string homeTown, name;

	cout << "What is your home town?" << endl;
	cin >> homeTown;
	if ( homeTown.size() > 6 )
	{
		cout << endl << "That's a long name!" << endl;
	}

	cout << "What is your name?";
	cin >> name;

	cout << "Hello," << name << "from" << homeTown << "!" << endl;

	return 0;
}